Cấu hình thông số database và địa chỉ website: 
Mở file functions.php và khai báo các giá trị: 
  - DB_HOST      : Địa chỉ mysql server (database server)
  - DB_USERNAME  : username kết nối đến database 
  - DB_PASSWORD  : mật khẩu kết nối đến database
  - DB_NAME  : tên database sẽ kết nối đến
  - BASE_DIR  : folder chứa các file trong website
