<link rel="stylesheet" href="./main.css">
<footer>
    <div class="footer row">
        <div class="col-4">
            <div class="footer-logo">
                <img src="https://s1.vnecdn.net/vnexpress/restruct/i/v453/v2_2019/pc/graphics/logo.svg" alt="">
            </div>
            <p class="txtf">CHúng tôi luôn mang đến cho bạn những thông tin mới nhất về mọi mặt của đời sống để mang đến cho bạn những góc nhìn đa chiều về đời sống</p>
        </div>
        <div class="col-4">
            <div class="footer-title">
                Link mạng xã hội
            </div>
            <div class="footer-social">
                <a href="" class="socail-f">
                    <i class='bx bxl-facebook'></i>
                </a>
                <a href="" class="socail-ins">
                    <i class='bx bxl-instagram'></i>
                </a>
                <a href="" class="socail-tw">
                    <i class='bx bxl-twitter'></i>
                </a>
                <a href="" class="socail-yb">
                    <i class='bx bxl-youtube'></i>
                </a>
                <a href="" class="socail-g">
                    <i class='bx bxl-google-plus'></i>
                </a>
            </div>
        </div>
        <div class="col-4">
            <div class="footer-title">
                Kết Nối Với Chúng tôi
            </div>
            <div class="footer-connect">
                <a class="connect-line">
                    Giới thiệu
                </a>
                <a class="connect-line">
                    Liên hệ
                </a>
                <a class="connect-line">
                    Các chuyên mục
                </a>
            </div>
        </div>
    </div>
    <div class="copyright">
        <div class="footer-title">
            Phát triển bởi  <b style="color:yellow"><?=$site_info['tenAdmin']?></b>  -  <?=date('Y');?>
        </div>
    </div>
</footer>